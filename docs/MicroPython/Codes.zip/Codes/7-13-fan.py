'''
 * Filename    : 7-13-fan
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
---------------------------------------------
电机转动逻辑表：
---------------------------------------------
  IO18(MA) 	| IO17(MB)  |     电机状态		|
---------------------------------------------
  HIGH 		|   LOW   	|       正转 		|
---------------------------------------------
   LOW 		|  HIGH  	|       反转 		|
---------------------------------------------
  HIGH 		|  HIGH  	|   停止（逐渐停止） |
---------------------------------------------
   LOW 		|   LOW   	|   刹停（直接刹停）	|
---------------------------------------------
'''

from machine import Pin
import time

#设置电机控制引脚A为IO18
MA = Pin(18,Pin.OUT)
#设置电机控制引脚B为IO17
MB = Pin(17,Pin.OUT)

while True:
    #正转
    MA.on()
    MB.off()
    time.sleep(2)
    #反转
    MA.off()
    MB.on()
    time.sleep(2)
    #停止
    MA.off()
    MB.off()
    time.sleep(2)