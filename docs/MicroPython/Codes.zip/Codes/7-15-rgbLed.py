'''
 * Filename    : 7-15-rgbLed
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
#Import Pin, neopiexl and time modules.
from machine import Pin
import neopixel
import time

pin = Pin(16, Pin.OUT)	#定义控制SK6812引脚为IO16
num_pixels = 12			#设置SK6812灯珠数量为12
#初始化SK6812灯珠
np = neopixel.NeoPixel(pin, num_pixels)

red = [255,0,0]	#显示为的红色数据

while True:
    np[0] = red		#在第1个灯珠显示红色12个灯珠，位置号是0-11
    np.write()		#刷新显示，只有刷新显示才能显示设置好的颜色
    