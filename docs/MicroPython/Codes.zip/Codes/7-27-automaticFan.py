'''
 * Filename    : 7-27-autimaticFan
 * Thonny      : Thonny 4.1.4
 * Author      : http://www.keyestudio.com
'''
#从 machine 模块中导入 I2C 和 Pin 类
from machine import I2C, Pin
#从 aht20库中导入 AHT20 类
from aht20 import AHT20
import time
#创建一个I2C对象并添加SDA与SCL引脚
i2c = I2C(scl=Pin(22), sda=Pin(21))
#创建一个AHT20对象，初始化时传入之前创建的I2C对象，以便通过I2C总线与AHT20传感器进行通信。
sensor = AHT20(i2c)

pir = Pin(19,Pin.IN)
#设置电机控制引脚A为IO18
MA = Pin(18,Pin.OUT)
#设置电机控制引脚B为IO17
MB = Pin(17,Pin.OUT)

while True:		#进入一个无限循环，持续读取传感器数据。
    try:
        #将温度和湿度的值存储到temperature和humidity变量中
        temperature, humidity = sensor.read_temperature_humidity()
        Pir = pir.value()
        #判断PIR是否检测到人与温度是否大于28度如果是电机转动否则电机不转
        if Pir == 1 and temperature > 28:
            MA.on()
            MB.off()
        else:
            MA.off()
            MB.off()
    #数据读取检测如果出错则打印“Failed to read from sensor:”
    except RuntimeError as e:
        print("Failed to read from sensor: ", e)
    time.sleep(1)	#延时1S