'''
 * Filename    : 7-35-wifiWebpageDisplay
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import network
import socket
import time
import json
import machine
from machine import Pin, ADC, I2C,SoftI2C,PWM
import aht20

# WiFi连接信息
# SSID = '你的WiFi名称'  # 你的WiFi网络名称
# PASSWORD = '你的WiFi密码'  # 你的WiFi密码
SSID = 'ChinaNet_2.4G'  # 你的WiFi网络名称
PASSWORD = 'ChinaNet@233'  # 你的WiFi密码

# 初始化传感器
# 光敏传感器
light_sensor = ADC(Pin(36))
light_sensor.atten(ADC.ATTN_11DB)

# 超声波传感器
# 定义超声波测距模块的控制引脚
Trig = Pin(5, Pin.OUT) 
Echo = Pin(4, Pin.IN)

distance = 0 # 将初始距离定义为0
soundVelocity = 340 #Set the speed of sound.

# PIR传感器
pir_sensor = Pin(19, Pin.IN)

# AHT20传感器
i2c = SoftI2C(scl=Pin(22), sda=Pin(21))
aht20Sensor = aht20.AHT20(i2c)

def getDistance():
    # Trig脚保持高电平10us以启动超声波模块
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    #开始计时，超声波在空气中传播初始时间
    while Echo.value() == 0:
        Start = time.ticks_us()
    #接收到反射回的超声波的时间
    while Echo.value() == 1:
        Stop = time.ticks_us()
    #接收到的时间减去初始时间，就是总时间
    Time = time.ticks_diff(Stop,Start)
    #按照公式计算距离得出的结果以米为单位。
    #除以1000换算成以厘米为单位。
    distance =  Time * soundVelocity //2 // 10000
    #返回计算的结果
    return distance

# 连接到WiFi
def connect_wifi(ssid, password):
    wlan = network.WLAN(network.STA_IF)  # 创建WLAN对象，使用STA模式（客户端模式）
    wlan.active(True)  # 激活WLAN接口
    wlan.connect(ssid, password)  # 连接到指定的WiFi网络

    timeout = 10  # 连接超时时间，单位为秒
    while not wlan.isconnected() and timeout > 0:  # 在未连接成功且超时时间未到时，重复检查连接状态
        print("Connecting to WiFi...")
        time.sleep(1)
        timeout -= 1

    if not wlan.isconnected():  # 如果超时仍未连接成功，抛出异常
        raise Exception("Could not connect to WiFi")
    
    print('Network config:', wlan.ifconfig())  # 输出网络配置（IP地址、子网掩码、网关和DNS）
    print('Connected to WiFi, IP address:', wlan.ifconfig()[0])  # 输出连接成功后的IP地址
    return wlan

# 创建HTML页面
def web_page():
    html = """<html>
    <head>
        <title>ESP32 Sensor Data</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; }
            .sensor { font-size: 24px; margin-top: 20px; }
        </style>
        <script>
            function updateData() {
                fetch('/sensor_data').then(function(response) {
                    return response.json();
                }).then(function(data) {
                    document.getElementById('light').innerText = data.light;
                    document.getElementById('distance').innerText = data.distance;
                    document.getElementById('pir').innerText = data.pir ? "Motion Detected" : "No Motion";
                    document.getElementById('temperature').innerText = data.temperature;
                    document.getElementById('humidity').innerText = data.humidity;
                });
            }
            setInterval(updateData, 1000);
        </script>
    </head>
    <body>
        <h1>ESP32 Sensor Data</h1>
        <div class="sensor">Light Sensor Value: <span id="light"></span></div>
        <div class="sensor">Distance: <span id="distance"></span> cm</div>
        <div class="sensor">PIR Sensor: <span id="pir"></span></div>
        <div class="sensor">Temperature: <span id="temperature"></span> C</div>
        <div class="sensor">Humidity: <span id="humidity"></span> %</div>
    </body>
    </html>"""
    return html  # 返回包含传感器数据的HTML页面

# 启动Web服务器
def start_server():
    wlan = connect_wifi(SSID, PASSWORD)  # 连接到WiFi
    addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]  # 获取本地IP地址，端口为80
    s = socket.socket()  # 创建一个套接字对象
    s.bind(addr)  # 将套接字绑定到地址和端口
    s.listen(5)  # 开始监听传入连接，最大连接数为5
    print('Listening on', addr)  # 打印服务器正在监听的地址和端口

    while True:
        cl, addr = s.accept()  # 接受一个客户端连接
        print('Client connected from', addr)  # 打印客户端的地址
        request = cl.recv(1024)  # 接收客户端请求，最多接收1024字节
        request = str(request)  # 将请求转换为字符串
        print('Content = %s' % request)  # 打印请求内容
        
        if 'GET /sensor_data' in request:
            light_value = light_sensor.read()
            distance = getDistance()
            pir_value = pir_sensor.value()
            temperature, humidity = aht20Sensor.read_temperature_humidity()

            sensor_data = {
                'light': light_value,
                'distance': distance,
                'pir': pir_value,
                'temperature': temperature,
                'humidity': humidity
            }

            response = 'HTTP/1.1 200 OK\nContent-Type: application/json\n\n'
            response += json.dumps(sensor_data)
            cl.send(response)
        else:
            response = web_page()
            cl.send('HTTP/1.1 200 OK\n')
            cl.send('Content-Type: text/html\n')
            cl.send('Connection: close\n\n')
            cl.sendall(response)
        cl.close()

# 运行服务器
try:
    start_server()  # 尝试启动Web服务器
except Exception as e:
    print('Failed to start server:', e)  # 如果启动失败，打印错误信息
    machine.reset()  # 重启设备以尝试重新连接
