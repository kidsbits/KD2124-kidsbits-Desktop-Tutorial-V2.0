'''
 * Filename    : 7-24-electricFan
 * Thonny      : Thonny 4.1.4
 * Author      : http://www.keyestudio.com
'''
from machine import Pin,ADC
import time

key = ADC(Pin(33))			#设置 GPIO 33 作为 ADC 的输入引脚
key.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
key.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

#设置电机控制引脚A为IO18
MA = Pin(18,Pin.OUT)
#设置电机控制引脚B为IO17
MB = Pin(17,Pin.OUT)

while True:
    item = key.read()	#读取按键的模拟值
    if item > 3500:	#判断红色按键是否按下，如果是电机就停止转动
        MA.off()
        MB.off()
    elif item > 2000 and item < 3000:	#判断黄色按键是否按下，如果是电机运行
        MA.on()
        MB.off()
    time.sleep_ms(300)
