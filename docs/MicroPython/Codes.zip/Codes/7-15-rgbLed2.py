'''
 * Filename    : 7-15-rgbLed2
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
 ----------------------------------------
    color = [red,green,blue]
    color 是变量用来存放颜色数据
    red.green,blue是对应颜色是值,值的范围是0-255
    比如你要显示红色就是[255,0,0]
    你可以通过RGB颜色对照表去设置你想要显示的颜色
'''
#Import Pin, neopiexl and time modules.
from machine import Pin
import neopixel
import time

pin = Pin(16, Pin.OUT)	#定义控制SK6812引脚为IO16
num_pixels = 12			#设置SK6812灯珠数量为12
#初始化SK6812灯珠
np = neopixel.NeoPixel(pin, num_pixels)
red = [255,0,0]	#红色
green = [0,255,0]#绿色
blue = [0,0,255]	#蓝色

while True:
    for i in range(num_pixels):		#使用for循环将i的值从0加到11
        np[i] = red		#在第i个灯珠显示红色
        np.write()		#刷新显示，只有刷新显示才能显示设置好的颜色
        time.sleep_ms(50)	#50ms的延时这样就能看到灯圈的颜色是慢慢变化的
    time.sleep(1)	#全部显示后停顿1秒
    for i in range(num_pixels):
        np[i] = green		#在第i个灯珠显示绿色
        np.write()	
        time.sleep_ms(50)
    time.sleep(1)
    for i in range(num_pixels):	
        np[i] = blue		#在第i个灯珠显示蓝色
        np.write()
        time.sleep_ms(50)
    time.sleep(1)
    
