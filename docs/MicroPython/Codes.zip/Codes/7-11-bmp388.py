'''
 * Filename    : 7-11-bmp388
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
#从 BMP388 库中导入 BMP388 类
from bmp388 import BMP388 
import time

# 创建BMP388对象设置SDA与SCL引脚，设置IIC频率为100KHz
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21), freq=100000)

#创建一个BMP388对象。将之前创建的i2c对象传递给它，以便通过I2C总线与BMP388传感器通信，设置BMP388 IIC地址为0x76
bmp = BMP388(i2c, i2c_addr=0x76)

while True:
    # 读取温度值
    temperature = bmp.read_temperature()
    # 读取气压值
    pressure = bmp.read_pressure()
    # 打印读取的数据
    print("Temperature:", temperature, "C "," Pressure:", pressure, "Pa")
    time.sleep(1)

