'''
 * Filename    : 7-33-compass
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
-----------------------------------------
方向与角度的关系：
    0° 是正北方
    90° 是正东方
    180° 是正南方
    270° 是正西方
'''
import machine
import time
from machine import Pin
#从 AK8975C 库中导入 ak8975c 类
from AK8975C import ak8975c
from oled import OLED

scl = Pin(22)
sda = Pin(21)
# 初始化I2C接口
i2c = machine.SoftI2C(scl, sda)
# 创建OLED实例
oled = OLED(i2c)
#创建一个 ak8975c 对象，初始化时传入 I2C 总线编号和 SCL、SDA 引脚。
Triaxial = ak8975c(scl, sda)

while True:
    Triaxial.measure()  # 测量数据
    if Triaxial.AK8975_GET_AZIMUTH(Triaxial.X, Triaxial.Y) == True:  # 只有在能计算出角度时候才打印航向角的值
        direction = Triaxial.angle_val
        print('degree:', direction,'°')
        # 清空显示
    oled.clear()
    if	direction >= 175 and direction <= 185:	#通过角度值判断方向
        oled.show_arrow_up()			#向上箭头
    elif direction >= 265 and direction <= 275:
        oled.show_arrow_left()			#向左箭头
    elif  direction <= 5:
        oled.show_arrow_down()			#向下箭头
    elif direction >= 85 and direction <= 95:
        oled.show_arrow_right()			#向右箭头
    oled.oled.show()
    time.sleep(0.3)
    