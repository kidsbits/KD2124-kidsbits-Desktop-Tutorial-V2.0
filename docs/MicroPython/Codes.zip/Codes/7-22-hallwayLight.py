'''
 * Filename    : 7-22-hallwayLight
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,ADC
import time

light = ADC(Pin(36))
light.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
light.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

sound = ADC(Pin(34))
sound.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
sound.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

led = Pin(23,Pin.OUT)

while True:
    #读取light传感器的值，并判断是否小于500，大于500则不进人循环
    while light.read() < 500:
        #读取声音传感器的值，并判断是否大于200，条件满足则打开led灯5秒
        if sound.read() > 200:
            led.on()
            time.sleep(5)
            led.off()