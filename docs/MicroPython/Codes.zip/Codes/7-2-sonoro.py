'''
 * Filename    : 7-2-sound
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
# Import Pin, ADC and DAC modules.
from machine import ADC,Pin
import time

adc=ADC(Pin(34))			#设置 GPIO 34 作为 ADC 的输入引脚
adc.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
adc.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

# Read ADC value once every 0.1seconds, convert ADC value to DAC value and output it,
# and print these data to “Shell”.
while True:				#无限循环，这样就能一直重复执行代码
        adcVal = adc.read()				#读取声音传感器的模拟值并赋值给变量adcVal
        print("Sonoro ADC Val:",adcVal) #使用串口打印adcVal的值
        time.sleep_ms(50)					#延时50mS
