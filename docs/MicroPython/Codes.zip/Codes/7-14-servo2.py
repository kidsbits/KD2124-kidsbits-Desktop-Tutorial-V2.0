'''
 * Filename    : 7-14-servo2
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
import time
#从servo库中导入Servo类
from servo import Servo

servo = Servo(pin=25)  # 请根据实际连接选择引脚

while True:
    #舵机从0度旋转到180度
    for angle in range(0,180):
        servo.set_angle(angle)  # 将舵机旋转到180度
        time.sleep_ms(10)		#延时10ms
    #舵机从180度旋转到0度
    for angle in range(180,-1,-1):
        servo.set_angle(angle)  # 将舵机旋转到0度
        time.sleep_ms(10)

