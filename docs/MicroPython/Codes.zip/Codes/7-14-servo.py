'''
 * Filename    : 7-14-servo
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
import time
#从servo库中导入Servo类
from servo import Servo

servo = Servo(pin=25)  # 请根据实际连接选择引脚

while True:
    # 设置角度
    servo.set_angle(0)  # 将舵机旋转到0度
    time.sleep(1)
    servo.set_angle(90)  # 将舵机旋转到90度
    time.sleep(1)
    servo.set_angle(180)  # 将舵机旋转到180度
    time.sleep(1)
