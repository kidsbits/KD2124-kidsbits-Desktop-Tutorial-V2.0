'''
 * Filename    : 7-3-pir
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

PIR = Pin(19, Pin.IN)  # 设置IO19为pir输入引脚
while True:				#无限循环，这样就能一直重复执行代码
    PIR_value = PIR.value()	#读取Pir传感器的感应值并赋值给变量value
    print(PIR_value, end = " ") #打印变量PIR_value的值，并且不换行
    if PIR_value == 1:		#判断变量PIR_value的值是否等于1，
        print("Some body is in this area!")#如果PIR_value等于1则执行打印代码
    else:	#否则执行下方的代码
        print("No one!")
    time.sleep(0.1)	#延时0.1S也就是100ms