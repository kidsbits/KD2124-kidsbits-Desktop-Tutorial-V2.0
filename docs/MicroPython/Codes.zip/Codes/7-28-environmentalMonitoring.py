'''
 * Filename    : 7-28-environmentalMonitoring
 * Thonny      : Thonny 4.1.4
 * Author      : http://www.keyestudio.com
'''
import machine
#从 machine 模块中导入 I2C 和 Pin 类
from machine import I2C, Pin
#从 aht20库中导入 AHT20 类
from aht20 import AHT20
#从 BMP388 库中导入 BMP388 类
from bmp388 import BMP388
from oled import OLED
import time

#创建一个I2C对象并添加SDA与SCL引脚
i2c = I2C(scl=Pin(22), sda=Pin(21))
#创建一个AHT20对象，初始化时传入之前创建的I2C对象，以便通过I2C总线与AHT20传感器进行通信。
sensor = AHT20(i2c)

# 创建BMP388对象设置SDA与SCL引脚，设置IIC频率为100KHz
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21), freq=100000)

#创建一个BMP388对象。将之前创建的i2c对象传递给它，以便通过I2C总线与BMP388传感器通信，设置BMP388 IIC地址为0x76
bmp = BMP388(i2c, i2c_addr=0x76)

# 创建OLED实例
oled = OLED(i2c)
# 清空显示
oled.clear()
'''
str()函数是就其他类型的变量转成string类型的变量
int()函数是将其他类型的变量转成int类型的变量，这里之所以要转换是为了不要有小数后面的数据显示
气压单位转换：1 hPa = 1 × 100 Pa = 100 Pa

'''

while True:		#进入一个无限循环，持续读取传感器数据。
    try:
        #将温度和湿度的值存储到temperature和humidity变量中
        temperature, humidity = sensor.read_temperature_humidity()
        # 读取气压值
        pressure = bmp.read_pressure() // 100 #将气压值除以100，就把Pa转换成了hPa        
        # 清空显示
        oled.clear()
        # 显示气压
        oled.show_text("Pressure:", 0, 0)
        oled.show_text(str(int(pressure)), 70, 0)
        oled.show_text("hPa", 105, 0)
        #显示温度
        oled.show_text("Temperature:", 0, 15)
        oled.show_text(str(int(temperature)), 100, 15)
        oled.show_text("C", 120, 15)
        #显示s湿度
        oled.show_text("Humidity:", 0, 30)
        oled.show_text(str(int(humidity)), 75, 30)
        oled.show_text("%", 105, 30)

        # 运行显示
        oled.oled.show()
    #数据读取检测如果出错则打印“Failed to read from sensor:”
    except RuntimeError as e:
        print("Failed to read from sensor: ", e)
    time.sleep(1)	#延时1S

