'''
 * Filename    : 7-19-tableLamp
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,ADC
import time

led = Pin(23,Pin.OUT)
key = ADC(Pin(33))			#设置 GPIO 33 作为 ADC 的输入引脚
key.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
key.width(ADC.WIDTH_12BIT)	#设置ADC分辨率
#定义一个变量用来切换led状态
ledState = False

while True:
    keyVal = key.read()	#读取按键的模拟值
    if keyVal > 3500:	#如果按键模拟值大于3500那就是红色按键按下了
        #对变量ledState进行取反，也就是如果是False（1）就变成True（0），True就变成False
        ledState = not ledState
        time.sleep_ms(500)
    #led.value()与led.on()和led.off()不同,led.value()需要再括号中添加0（led灭）或者1（led亮）
    led.value(ledState)
