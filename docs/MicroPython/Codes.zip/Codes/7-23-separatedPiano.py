'''
 * Filename    : 7-23-separatedPiano
 * Thonny      : Thonny 4.1.4
 * Author      : http://www.keyestudio.com
'''

from machine import Pin, PWM
import time

# 设置IO32为PWM输出引脚，频率为5000 Hz，占空比为0
trumpet = PWM(Pin(32), freq=5000, duty=0)

# 定义一个数组用来存储频率
a = [523, 587, 659, 698, 784, 880, 988]

# 定义超声波测距模块的控制引脚
Trig = Pin(5, Pin.OUT)
Echo = Pin(4, Pin.IN)

distance = 0  # 初始距离定义为0
soundVelocity = 340  # 声速设定为340 m/s

def getDistance():
    """
    驱动超声波模块测量距离
    :return: 测量的距离（单位：cm）
    """
    # Trig脚保持高电平10us以启动超声波模块
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    
    # 等待Echo引脚变高，记录开始时间
    while Echo.value() == 0:
        Start = time.ticks_us()
        
    # 等待Echo引脚变低，记录结束时间
    while Echo.value() == 1:
        Stop = time.ticks_us()
    
    # 计算Echo引脚高电平持续时间
    Time = time.ticks_diff(Stop, Start)
    # 根据时间计算距离，单位为厘米
    distanceVal = Time * soundVelocity // 2 // 10000
    return distanceVal

def play_tone(index):
    """
    播放指定音阶
    :param index: 音阶索引
    """
    trumpet.duty(10)  # 控制PWM的占空比（0-255），可以调节声音大小
    trumpet.freq(a[index])  # 设置PWM频率为对应音阶频率
    time.sleep_ms(300)  # 播放音阶300毫秒
    trumpet.duty(0)  # 停止播放

while True:
    distance = getDistance()  # 获取距离 
    # 根据测量的距离播放对应的音阶
    if 5 < distance < 10:
        print("Do")
        play_tone(0)
    elif 10 < distance < 15:
        print("Re")
        play_tone(1)
    elif 15 < distance < 20:
        print("Mi")
        play_tone(2)
    elif 20 < distance < 25:
        print("Fa")
        play_tone(3)
    elif 25 < distance < 30:
        print("So")
        play_tone(4)
    elif 30 < distance < 35:
        print("La")
        play_tone(5)
    elif 35 < distance < 40:
        print("Si")
        play_tone(6)
    
    time.sleep_ms(100)  # 每次测量后等待1秒
