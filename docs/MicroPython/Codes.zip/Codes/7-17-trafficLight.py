'''
 * Filename    : 7-17-trafficLight
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

redLED = Pin(23,Pin.OUT)	#设置IO23作为红色led控制引脚
greenLED = Pin(27,Pin.OUT)	#设置IO27作为绿色LED控制引脚
yellowLED = Pin(26,Pin.OUT)	#设置IO26作为黄色LED控制引脚

#关闭红绿黄三个led灯，避免影响
redLED.off()
greenLED.off()
yellowLED.off()

#绿色led灯亮5S后熄灭同时黄色led闪烁3次，然后红色led灯亮5S后熄灭，以此循环
while True:
    greenLED.on()
    time.sleep(5)
    greenLED.off()
    for i in range(0,3):
        yellowLED.on()
        time.sleep(0.5)
        yellowLED.off()
        time.sleep(0.5)
    redLED.on()
    time.sleep(5)
    redLED.off()