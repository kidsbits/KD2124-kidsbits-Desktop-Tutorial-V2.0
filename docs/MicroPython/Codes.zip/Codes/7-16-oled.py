'''
 * Filename    : 7-16-oled
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
-----------------------------------------
oled.clear()
清除显示，如果要显示新的内容就要清楚上一次显示的内容不然两个内容会重叠

oled.oled.show()
刷新显示，设置好显示内容后需要刷新才能显示到OLED上

oled.show_text("******", X,Y)
设置显示内容代码，在双引号中输入需要显示的内容，
然后设置值X，Y的值这样可以控制显示内容的起始位置
'''
import machine
from oled import OLED

# 初始化I2C接口
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21))

# 创建OLED实例
oled = OLED(i2c)

# 清空显示
oled.clear()

# 显示文本
oled.show_text("KEYESTUTDIO", 20, 0)

# 显示更多文本
oled.show_text("Hello World!", 20, 10)
oled.show_text("MicroPython", 20, 20)

# 运行显示
oled.oled.show()
