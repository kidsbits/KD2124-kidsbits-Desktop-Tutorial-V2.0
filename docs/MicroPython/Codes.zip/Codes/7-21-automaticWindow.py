'''
 * Filename    : 7-21-automaticWindow
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import ADC,Pin
import time
#从servo库中导入Servo类
from servo import Servo

servo = Servo(pin=25)  #设置控制引脚为IO25

adc=ADC(Pin(36))			#设置 GPIO 36 作为 ADC 的输入引脚
adc.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
adc.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

while True:
    light = adc.read()
    if light < 500:	#判断变量light是否小于500
        servo.set_angle(180)  # 设置角度为180度
    else:
        servo.set_angle(0)  # 设置角度为0度
    time.sleep_ms(300)