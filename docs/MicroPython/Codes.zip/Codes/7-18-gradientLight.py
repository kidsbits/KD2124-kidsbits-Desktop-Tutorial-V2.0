'''
 * Filename    : 7-18-gradientLight
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin, PWM  
import time  
  
# 设置PWM引脚和频率  
pwm_pin = Pin(23, Pin.OUT)  
pwm = PWM(pwm_pin, freq=1000)  # 频率设为1000Hz  
  
# 呼吸灯循环  
while True:  
    for duty in range(0, 1024, 5):  # 亮度增加  
        pwm.duty(duty)  
        time.sleep_ms(10)  # 稍作延时以观察渐变效果  
    for duty in range(1023, -1, -5):  # 亮度减少  
        pwm.duty(duty)  
        time.sleep_ms(10)