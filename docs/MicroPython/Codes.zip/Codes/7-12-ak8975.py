'''
 * Filename    : 7-12-ak8975
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
#从 AK8975C 库中导入 ak8975c 类
from AK8975C import ak8975c
import time

scl = Pin(22)
sda = Pin(21)
bus = 0		#指定 I2C 总线的编号
#创建一个 ak8975c 对象，初始化时传入 I2C 总线编号和 SCL、SDA 引脚。
Triaxial = ak8975c(bus, scl, sda)

while True:
    Triaxial.measure()  # 测量数据
    print('x:',Triaxial.X,'y:',Triaxial.Y,'z:',Triaxial.Z)  # 打印XYZ轴的地磁强度
    if Triaxial.AK8975_GET_AZIMUTH(Triaxial.X, Triaxial.Y) == True:  # 只有在能计算出角度时候才打印航向角的值
        print('degree:', Triaxial.angle_val,'°')