'''
 * Filename    : 7-6-adKey
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
# Import Pin and ADC modules.
from machine import ADC,Pin
import time 

adc=ADC(Pin(33))			#设置 GPIO 33 作为 ADC 的输入引脚
adc.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
adc.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

while True:					#无限循环，这样就能一直重复执行代码
    adcVal = adc.read() 	#读取AD按键的模拟值并赋值给变量adcVal
    print("adcVal:",adcVal)	#打印adcVal的模拟值
    time.sleep(0.3)			#延时0.3S