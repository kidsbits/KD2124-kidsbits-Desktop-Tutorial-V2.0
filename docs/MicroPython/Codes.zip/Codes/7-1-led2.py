'''
 * Filename    : 7-1-led2
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import time

led = Pin(23,Pin.OUT) 	# 设置一个led对象并将其连接到引脚IO23，将引脚设置为输出

while True:					#无限循环，这样就能一直重复执行代码
    led.on()				#红色led灯亮
    time.sleep_ms(200)		#延时200mS
    led.off()				#红色led灯灭
    time.sleep_ms(200)		#延时200mS

