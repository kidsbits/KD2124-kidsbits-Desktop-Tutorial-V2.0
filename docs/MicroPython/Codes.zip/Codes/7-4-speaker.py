'''
 * Filename    : 7-4-speaker
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
 
-----------------------------
| Pitch names |  Frequency  |
|---------------------------|
|    C(Do)    |     523     |
|    D(Re)    |     587     |
|    E(Mi)    |     659     |
|    F(Fa)    |     698     |
|    G(So)    |     784     |
|    A(La)    |     880     |
|    B(Si)    |     988     |
-----------------------------

'''
from machine import Pin, PWM
import time

#设置IO32为PWM输出引脚，频率为5000 Hz，占空比为50% (8位分辨率中间值为128，占空比范围0-255)
trumpet = PWM(Pin(32), freq=5000, duty=128) 


a = [523,587,659,698,784,880,988] #定义一个数组用来存储频率

for i in a:				#for循环数组a有几组数据就能循环几次
    trumpet.duty(10)	#控制PWM的占空比（0-255），可以调节声音大小
    trumpet.freq(i)		#设置频率，控制频率就可以发出需要的声音
    time.sleep(0.5)		#延时0.5S
    trumpet.duty(0)		#将占空比设置成0，起到关闭扬声器的作用
