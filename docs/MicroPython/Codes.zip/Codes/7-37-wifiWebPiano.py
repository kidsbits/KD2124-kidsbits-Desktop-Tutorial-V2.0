'''
 * Filename    : 7-37-wifiWebPiano
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import network
import socket
import machine
import time

# WiFi连接信息
SSID = '你的WiFi名称'  # 你的WiFi网络名称
PASSWORD = '你的WiFi密码'  # 你的WiFi密码

# 连接到WiFi
def connect_wifi(ssid, password):
    wlan = network.WLAN(network.STA_IF)  # 创建WLAN对象，使用STA模式（客户端模式）
    wlan.active(True)  # 激活WLAN接口
    wlan.connect(ssid, password)  # 连接到指定的WiFi网络

    timeout = 10  # 连接超时时间，单位为秒
    while not wlan.isconnected() and timeout > 0:  # 在未连接成功且超时时间未到时，重复检查连接状态
        print("Connecting to WiFi...")
        time.sleep(1)
        timeout -= 1

    if not wlan.isconnected():  # 如果超时仍未连接成功，抛出异常
        raise Exception("Could not connect to WiFi")
    
    print('Network config:', wlan.ifconfig())  # 输出网络配置（IP地址、子网掩码、网关和DNS）
    print('Connected to WiFi, IP address:', wlan.ifconfig()[0])  # 输出连接成功后的IP地址
    return wlan

# 创建HTML页面
def web_page():
    html = """<html>
    <head>
        <title>ESP32 Web Server</title>
        <style>
            body { font-family: Arial, sans-serif; text-align: center; }
            button { padding: 10px 20px; font-size: 16px; margin: 10px; }
        </style>
        <script>
            function playTone(tone) {
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "/play_" + tone, true);
                xhr.send();
            }
        </script>
    </head>
    <body>
        <h1>ESP32 Tone Player</h1>
        <button onclick="playTone('do')">Do</button>
        <button onclick="playTone('re')">Re</button>
        <button onclick="playTone('mi')">Mi</button>
        <button onclick="playTone('fa')">Fa</button>
        <button onclick="playTone('sol')">Sol</button>
        <button onclick="playTone('la')">La</button>
        <button onclick="playTone('si')">Si</button>
    </body>
    </html>"""
    return html  # 返回一个包含7个按键的HTML页面，每个按键对应一个音符

# 启动Web服务器
def start_server():
    wlan = connect_wifi(SSID, PASSWORD)  # 连接到WiFi
    addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]  # 获取本地IP地址，端口为80
    s = socket.socket()  # 创建一个套接字对象
    s.bind(addr)  # 将套接字绑定到地址和端口
    s.listen(5)  # 开始监听传入连接，最大连接数为5
    print('Listening on', addr)  # 打印服务器正在监听的地址和端口

    while True:
        cl, addr = s.accept()  # 接受一个客户端连接
        print('Client connected from', addr)  # 打印客户端的地址
        request = cl.recv(1024)  # 接收客户端请求，最多接收1024字节
        request = str(request)  # 将请求转换为字符串
        print('Content = %s' % request)  # 打印请求内容
        
        response = web_page()  # 生成HTML响应

        # 检查请求路径，并播放相应的音符
        if '/play_do' in request:
            play_tone('do')
        elif '/play_re' in request:
            play_tone('re')
        elif '/play_mi' in request:
            play_tone('mi')
        elif '/play_fa' in request:
            play_tone('fa')
        elif '/play_sol' in request:
            play_tone('sol')
        elif '/play_la' in request:
            play_tone('la')
        elif '/play_si' in request:
            play_tone('si')

        cl.send('HTTP/1.1 200 OK\n')
        cl.send('Content-Type: text/html\n')
        cl.send('Connection: close\n\n')
        cl.sendall(response)
        cl.close()  # 关闭客户端连接

# 播放音符
def play_tone(tone):
    tones = {
        'do': 261.63,
        're': 293.66,
        'mi': 329.63,
        'fa': 349.23,
        'sol': 392.00,
        'la': 440.00,
        'si': 493.88
    }
    frequency = tones.get(tone, 0)
    if frequency > 0:
        pwm = machine.PWM(machine.Pin(32))  # 使用GPIO32引脚输出PWM信号
        pwm.freq(int(frequency))
        pwm.duty(512)  # 设置占空比为50%
        time.sleep_ms(200)  # 播放音符1秒
        pwm.deinit()  # 关闭PWM

# 运行服务器
try:
    start_server()  # 尝试启动Web服务器
except Exception as e:
    print('Failed to start server:', e)  # 如果启动失败，打印错误信息
    machine.reset()  # 重启设备以尝试重新连接
