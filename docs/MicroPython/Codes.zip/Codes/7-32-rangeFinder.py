'''
 * Filename    : 7-32-rangeFinder
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
from machine import Pin,PWM
from oled import OLED
import time

# 初始化I2C接口
i2c = machine.SoftI2C(scl=machine.Pin(22), sda=machine.Pin(21))

# 创建OLED实例
oled = OLED(i2c)


# 定义超声波测距模块的控制引脚
Trig = Pin(5, Pin.OUT) 
Echo = Pin(4, Pin.IN)

distance = 0 # 将初始距离定义为0
soundVelocity = 340 #Set the speed of sound.

def getDistance():
    # Trig脚保持高电平10us以启动超声波模块
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    #开始计时，超声波在空气中传播初始时间
    while Echo.value() == 0:
        Start = time.ticks_us()
    #接收到反射回的超声波的时间
    while Echo.value() == 1:
        Stop = time.ticks_us()
    #接收到的时间减去初始时间，就是总时间
    Time = time.ticks_diff(Stop,Start)
    #按照公式计算距离得出的结果以米为单位。
    #除以1000换算成以厘米为单位。
    distance =  Time * soundVelocity //2 // 10000
    #返回计算的结果
    return distance

while True:
    #将测量的距离值赋值给变量distance
    distance = getDistance()
    # 清空显示
    oled.clear()
    #显示distance
    oled.show_text("Distance:", 0, 0)
    #使用str()将变量distance的值变成字符串
    oled.show_text(str(distance), 0, 10)
    oled.show_text("CM", 30, 10)
    oled.oled.show()
    time.sleep(1)

