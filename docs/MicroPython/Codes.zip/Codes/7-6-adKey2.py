'''
 * Filename    : 7-6-adKey2
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
# Import Pin and ADC modules.
from machine import ADC,Pin
import time 

adc=ADC(Pin(33))			#设置 GPIO 33 作为 ADC 的输入引脚
adc.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
adc.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

while True:					#无限循环，这样就能一直重复执行代码
    itme = adc.read() 	#读取AD按键的模拟值并赋值给变量itme
    if itme > 3500:	#判断变量itme是否大于3500，如果是则打印“Red”
        print("Red")
    elif (itme > 2000) and (itme < 3000):	#判断itme是否大于2000小于3000如果是则打印“Yellow”
        print("Yellow")
    elif itme > 900 and itme < 1500:	#判断itme是否大于900小于1500如果是则打印“Yellow”
        print("Green")
    time.sleep(0.3)		#延时0.3S
