'''
 * Filename    : 7-5-lighr
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
# Import Pin, ADC and DAC modules.
from machine import ADC,Pin,DAC
import time

adc=ADC(Pin(36))			#设置 GPIO 36 作为 ADC 的输入引脚
adc.atten(ADC.ATTN_11DB)	#设置电压范围是0-3.3V
adc.width(ADC.WIDTH_12BIT)	#设置ADC分辨率

while True:				#无限循环，这样就能一直重复执行代码
    adcVal=adc.read()	#读取声音传感器的模拟值并赋值给变量adcVal
    print("ADC Val:",adcVal)	#打印adcVal的值
    time.sleep(0.5)				#延时0.5s