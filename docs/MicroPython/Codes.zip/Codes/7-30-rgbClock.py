'''
 * Filename    : 7-30-rgbClock
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin
import neopixel
import time  
  
hour = 10 	#设置小时
minute = 30 #设置分钟
second = 40	#设置秒钟

pin = Pin(16, Pin.OUT)	#定义控制SK6812引脚为IO16
num_pixels = 12			#设置SK6812灯珠数量为12
#初始化SK6812灯珠
np = neopixel.NeoPixel(pin, num_pixels)

red = [255,0,0]	#红色-hour
green = [0,255,0]#绿色-minute
blue = [0,0,255]	#蓝色-second
  
def setClock():  
    global hour, minute, second  # 使用global关键字来修改全局变量  
    second += 1  
    if second > 59:  
        second = 0  
        minute += 1  
        if minute > 59:  
            minute = 0  
            hour += 1  
            if hour > 12:  
                hour = 1  
    print(f"{hour:02d}:{minute:02d}:{second:02d}")  # 打印时间，格式化输出  
    time.sleep(1)  
  
while True:  
    setClock() 
    if second // 5 == 0:
        for i in range(0,11):	#清楚秒的显示
            np[i] = 0,0,0
        np[11] = blue
        np.write()		#刷新显示
    else:
        np[int(second // 5 - 1)] = blue
        np.write()		#刷新显示
    if minute // 5 == 0:
        np[11] = green
        np.write()		#刷新显示
    else:
        np[int(minute // 5 - 1)] = green
        np.write()		#刷新显示
    np[(hour-1)] = red
    np.write()		#刷新显示