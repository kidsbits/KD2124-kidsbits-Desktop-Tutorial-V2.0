'''
 * Filename    : 7-20-lntrusionAlarm
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time

#设置IO32为PWM输出引脚，频率为5000 Hz，占空比为50% (8位分辨率中间值为128，占空比范围0-255)
spk = PWM(Pin(32), freq=5000, duty=128)

redLED = Pin(23,Pin.OUT)
greenLED = Pin(27,Pin.OUT)
pir = Pin(19,Pin.IN)

while True:
    #读取pir传感器的值并赋值给变量PIR
    PIR = pir.value()
    print("pir:",PIR)	#打印PIR的值
    if PIR == 1:		#判断PIR的值是否等于1
        greenLED.off()	#绿灯灭
        redLED.on()		#红灯亮
        spk.duty(50)	#设置扬声器PWM占空比
        spk.freq(880)	#设置扬声器频率
    else:
        redLED.off()	#红灯灭
        greenLED.on()	#绿灯亮
        spk.duty(0)		#设置扬声器占空比为0，声音停止
    time.sleep(0.1)