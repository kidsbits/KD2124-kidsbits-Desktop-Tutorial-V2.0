'''
 * Filename    : 7-8-rfid
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import machine
import time
#从mfrc522_i2c库中导入mfrc522类
from mfrc522_i2c import mfrc522

#i2c config
addr = 0x28		#rfid的IIC通信地址
scl = 22		#IIC的SCL引脚
sda = 21		#IIC的SDA引脚

#创建一个MFRC522对象，传入I2C的SCL引脚、SDA引脚和设备地址。
rc522 = mfrc522(scl, sda, addr)
#初始化MFRC522模块。这是必要的步骤，确保模块处于工作状态。
rc522.PCD_Init()
#显示MFRC522读取器的详细信息，用于调试和确认设备工作正常。
rc522.ShowReaderDetails()        

while True:
    #检查是否有新的RFID卡片出现在读取器的感应范围内
    if rc522.PICC_IsNewCardPresent():
        #尝试读取卡片的序列号。如果成功读取到卡片的序列号，返回True。
        if rc522.PICC_ReadCardSerial() == True:
            #打印“Card UID:”字符与完整的UID值
            print("Card UID:",rc522.uid.uidByte[0 : rc522.uid.size])