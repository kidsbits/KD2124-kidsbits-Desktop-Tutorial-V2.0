'''
 * Filename    : 7-34-wifi
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
import network
import socket
import time
import machine

# WiFi连接信息
SSID = '你的WiFi名称'  # 你的WiFi网络名称
PASSWORD = '你的WiFi密码'  # 你的WiFi密码

# 连接到WiFi
def connect_wifi(ssid, password):
    wlan = network.WLAN(network.STA_IF)  # 创建WLAN对象，使用STA模式（客户端模式）
    wlan.active(True)  # 激活WLAN接口
    wlan.connect(ssid, password)  # 连接到指定的WiFi网络

    timeout = 10  # 连接超时时间，单位为秒
    while not wlan.isconnected() and timeout > 0:  # 在未连接成功且超时时间未到时，重复检查连接状态
        print("Connecting to WiFi...")
        time.sleep(1)
        timeout -= 1

    if not wlan.isconnected():  # 如果超时仍未连接成功，抛出异常
        raise Exception("Could not connect to WiFi")
    
    print('Network config:', wlan.ifconfig())  # 输出网络配置（IP地址、子网掩码、网关和DNS）
    print('Connected to WiFi, IP address:', wlan.ifconfig()[0])  # 输出连接成功后的IP地址
    return wlan

# 创建HTML页面
def web_page():
    html = """<html>
    <head>
        <title>ESP32 Web Server</title>
    </head>
    <body>
        <h1>Hello World</h1>
    </body>
    </html>"""
    return html  # 返回一个简单的HTML页面，内容为“Hello World”

# 启动Web服务器
def start_server():
    wlan = connect_wifi(SSID, PASSWORD)  # 连接到WiFi
    addr = socket.getaddrinfo('0.0.0.0', 80)[0][-1]  # 获取本地IP地址，端口为80
    s = socket.socket()  # 创建一个套接字对象
    s.bind(addr)  # 将套接字绑定到地址和端口
    s.listen(5)  # 开始监听传入连接，最大连接数为5
    print('Listening on', addr)  # 打印服务器正在监听的地址和端口

    while True:
        cl, addr = s.accept()  # 接受一个客户端连接
        print('Client connected from', addr)  # 打印客户端的地址
        request = cl.recv(1024)  # 接收客户端请求，最多接收1024字节
        request = str(request)  # 将请求转换为字符串
        print('Content = %s' % request)  # 打印请求内容
        
        response = web_page()  # 生成HTML响应
        cl.send('HTTP/1.1 200 OK\n')  # 发送HTTP响应头部
        cl.send('Content-Type: text/html\n')  # 指定内容类型为HTML
        cl.send('Connection: close\n\n')  # 关闭连接
        cl.sendall(response)  # 发送HTML页面内容
        cl.close()  # 关闭客户端连接

# 运行服务器
try:
    start_server()  # 尝试启动Web服务器
except Exception as e:
    print('Failed to start server:', e)  # 如果启动失败，打印错误信息
    machine.reset()  # 重启设备以尝试重新连接
