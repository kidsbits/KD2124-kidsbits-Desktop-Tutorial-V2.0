'''
 * Filename    : 7-29-parkingSensor
 * Thonny      : Thonny 4.1.4
 * Auther      : http//www.keyestudio.com
'''
from machine import Pin,PWM
import time

#设置IO32为PWM输出引脚，频率为5000 Hz，占空比为50% (8位分辨率中间值为128，占空比范围0-255)
spk = PWM(Pin(32), freq=5000, duty=128)
redLED = Pin(23,Pin.OUT)
greenLED = Pin(27,Pin.OUT)

# 定义超声波测距模块的控制引脚
Trig = Pin(5, Pin.OUT) 
Echo = Pin(4, Pin.IN)

distance = 0 # 将初始距离定义为0
soundVelocity = 340 #Set the speed of sound.

# getDistance()函数用于驱动超声波模块测量距离，

# Echo.value()用于读取超声波模块Echo引脚的状态，
# 然后使用时间模块的时间戳函数计算Echo的持续时间
# 引脚的高电平，根据时间计算测量距离并返回值。
def getDistance():
    # Trig脚保持高电平10us以启动超声波模块
    Trig.value(1)
    time.sleep_us(10)
    Trig.value(0)
    #开始计时，超声波在空气中传播初始时间
    while Echo.value() == 0:
        Start = time.ticks_us()
    #接收到反射回的超声波的时间
    while Echo.value() == 1:
        Stop = time.ticks_us()
    #接收到的时间减去初始时间，就是总时间
    Time = time.ticks_diff(Stop,Start)
    #按照公式计算距离得出的结果以米为单位。
    #除以1000换算成以厘米为单位。
    distance =  Time * soundVelocity //2 // 10000
    #返回计算的结果
    return distance

# 每500毫秒打印一次从超声波模块获得的数据
while True:    
    distance = getDistance()
    print('Distance: ',distance, 'cm')
    if distance > 40:	#判断距离是否大于40，如果是亮绿灯，扬声器不响；如果不是亮红灯扬声器响
        redLED.off()
        greenLED.on()
        spk.duty(0)	#扬声器不发声
    else:
        redLED.on()
        greenLED.off()
        spk.duty(50)	#设置扬声器PWM占空比
        spk.freq(880)	#设置扬声器频率
    time.sleep_ms(300)
